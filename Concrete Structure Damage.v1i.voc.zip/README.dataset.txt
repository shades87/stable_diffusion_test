# Concrete Structure Damage > 2024-04-18 9:02am
https://universe.roboflow.com/civil-engineering-dataset/concrete-structure-damage

Provided by a Roboflow user
License: CC BY 4.0

